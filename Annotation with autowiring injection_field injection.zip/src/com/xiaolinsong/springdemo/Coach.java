package com.xiaolinsong.springdemo;

public interface Coach {
	
	public String getDailyWorkout();
	
	public String getDailyFortune();

}

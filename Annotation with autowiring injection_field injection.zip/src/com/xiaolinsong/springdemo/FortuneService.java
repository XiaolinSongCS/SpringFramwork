package com.xiaolinsong.springdemo;

public interface FortuneService {
	
	public String getFortune();

}
